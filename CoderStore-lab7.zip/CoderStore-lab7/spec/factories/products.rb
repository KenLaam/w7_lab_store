FactoryGirl.define do
  factory :product do
    name "MyString"
description "MyText"
image_path "MyString"
price_vnd "9.99"
weight 1
  end

end
